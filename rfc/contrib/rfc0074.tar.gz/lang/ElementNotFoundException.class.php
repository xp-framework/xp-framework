<?php
/* This class is part of the XP framework
 *
 * $Id: ElementNotFoundException.class.php 5953 2005-10-08 09:53:35Z kiesel $
 */
 
  /**
   * Encapsulates ElementNotFoundException
   *
   * @see Exception
   */
  class ElementNotFoundException extends Exception {
  
  }
?>
