<?php
/* This class is part of the XP framework
 *
 * $Id: IllegalThreadStateException.class.php 1384 2003-05-24 18:25:16Z friebe $ 
 */

  /**
   * Indicate a thread is already running
   *
   * @purpose  Exception
   */
  class IllegalThreadStateException extends Exception {
  
  }
?>
