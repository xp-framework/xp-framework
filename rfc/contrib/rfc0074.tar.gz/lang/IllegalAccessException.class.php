<?php
/* This class is part of the XP framework
 *
 * $Id: IllegalAccessException.class.php 3362 2004-04-25 17:46:44Z friebe $
 */
 
  /**
   * An IllegalAccessException is thrown when an object is accessed 
   * in a way for which no permissions exist.
   *
   * @see      xp://lang.Exception
   * @purpose  Exception
   */
  class IllegalAccessException extends Exception {
  }
?>
