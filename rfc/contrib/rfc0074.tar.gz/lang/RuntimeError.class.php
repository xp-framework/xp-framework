<?php
/* This class is part of the XP framework
 *
 * $Id: RuntimeError.class.php 2342 2003-09-21 17:51:37Z friebe $ 
 */

  /**
   * Indicates an internal error has occured
   *
   * @purpose  Error
   */
  class RuntimeError extends Error {
  
  }
?>
