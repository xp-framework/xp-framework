<?php
/* This class is part of the XP framework
 *
 * $Id: Interface.class.php 6621 2006-02-22 13:09:48Z friebe $
 */
 
  /**
   * Class Interface is the root of all interfaces.
   *
   * @purpose  Interface
   */
  class Interface {
  
    /**
     * Constructor. Ensures interfaces cannot be instantiated.
     * 
     * @access  private
     */
    function Interface() {
      xp::error('Interfaces cannot be instantiated ('.get_class($this).')');
    }
  }
?>
