<?php
/* This class is part of the XP framework
 *
 * $Id: IllegalStateException.class.php 4883 2005-03-17 11:25:22Z kiesel $
 */
 
  /**
   * Encapsulates IllegalStateException
   *
   * @see Exception
   */
  class IllegalStateException extends Exception {
  
  }
?>
