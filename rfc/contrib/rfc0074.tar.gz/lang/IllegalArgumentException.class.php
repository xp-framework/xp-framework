<?php
/* This class is part of the XP framework
 *
 * $Id: IllegalArgumentException.class.php 3362 2004-04-25 17:46:44Z friebe $
 */
 
  /**
   * Thrown to indicate that a method has been passed an illegal or 
   * inappropriate argument.
   *
   * @see      xp://lang.Exception
   * @purpose  Exception
   */
  class IllegalArgumentException extends Exception {
  }
?>
