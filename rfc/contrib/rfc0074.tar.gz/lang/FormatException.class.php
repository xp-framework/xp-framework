<?php
/* This class is part of the XP framework
 *
 * $Id: FormatException.class.php 5953 2005-10-08 09:53:35Z kiesel $
 */
 
  /**
   * Encapsulates FormatException
   *
   * @see   xp://lang.Exception
   */
  class FormatException extends Exception {
  
  }
?>
