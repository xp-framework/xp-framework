<?php
/* This class is part of the XP framework
 *
 * $Id: ClassNotFoundException.class.php 5953 2005-10-08 09:53:35Z kiesel $
 */
 
  /**
   * Encapsulates ClassNotFoundException
   *
   * @see Exception
   */
  class ClassNotFoundException extends Exception {
  
  }
?>
