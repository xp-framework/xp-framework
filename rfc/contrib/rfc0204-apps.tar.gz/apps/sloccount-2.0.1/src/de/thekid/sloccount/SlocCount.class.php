<?php
/* This file is part of the XP framework
 *
 * $Id$
 */

  uses(
    'util.cmd.Command',
    'io.collections.FileCollection',
    'io.collections.iterate.FilteredIOCollectionIterator',
    'io.collections.iterate.NegationOfFilter',
    'io.collections.iterate.AnyOfFilter',
    'io.collections.iterate.RegexFilter',
    'io.collections.iterate.CollectionFilter'
  );

  /**
   * Counts lines of code
   *
   */
  class SlocCount extends Command {
    protected $collection= NULL;
  
    /**
     * Sets directory where to start at
     *
     * @param   string dir
     */
    #[@arg(position= 0)]
    public function setDirectory($dir) {
      $this->collection= new FileCollection($dir);
    }

    /**
     * Main runner method
     *
     */
    public function run() {
      $filter= new NegationOfFilter(new AnyOfFilter(array(
        new CollectionFilter(),
        new RegexFilter('/.svn/'),
        new RegexFilter('/CVS/')
      )));

      foreach (new FilteredIOCollectionIterator($this->collection, $filter, TRUE) as $element) {
        $this->out->writeLine('Counting lines in ', $element);
      }
    }
  }
?>
